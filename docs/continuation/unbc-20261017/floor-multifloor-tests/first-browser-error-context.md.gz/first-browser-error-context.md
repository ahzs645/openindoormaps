# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: indoor-floor-navigation.spec.ts >> complete-floor journey and both sides of an actual lift transition on desktop/mobile
- Location: tests/e2e/indoor-floor-navigation.spec.ts:33:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 5
Received: 7
```

# Page snapshot

```yaml
- main [ref=e3]:
  - navigation [ref=e5]:
    - button "Clear map" [ref=e6] [cursor=pointer]
    - group [ref=e7]:
      - generic "Loaded map" [ref=e8] [cursor=pointer]
    - button "Import project ZIP" [ref=e9] [cursor=pointer]
  - status [ref=e10]: Loaded 4 source areas · 1,864 mapped locations · 5,476 graph nodes · 2,586 review items.
  - region "Indoor campus map" [ref=e12]:
    - generic:
      - group "Map presentation" [ref=e13]:
        - button "2D floor map" [pressed] [ref=e14] [cursor=pointer]
        - button "3D rooms" [ref=e15] [cursor=pointer]
        - button "3D relative heights" [ref=e16] [cursor=pointer]
      - button "Open level selector" [ref=e18] [cursor=pointer]:
        - generic [ref=e19]: L4
        - generic [ref=e20]:
          - strong [ref=e21]: Floor 4
          - generic [ref=e22]: Campus · All buildings
        - img [ref=e23]
    - generic [ref=e26]:
      - generic [ref=e27]:
        - region "Map" [ref=e28]
        - group [ref=e29]:
          - generic "Toggle attribution" [ref=e30] [cursor=pointer]
          - generic [ref=e31]:
            - link "MapLibre" [ref=e32] [cursor=pointer]:
              - /url: https://maplibre.org/
            - text: "|"
            - link "OpenFreeMap" [ref=e33] [cursor=pointer]:
              - /url: https://openfreemap.org
            - link "© OpenMapTiles" [ref=e34] [cursor=pointer]:
              - /url: https://www.openmaptiles.org/
            - text: Data from
            - link "OpenStreetMap" [ref=e35] [cursor=pointer]:
              - /url: https://www.openstreetmap.org/copyright
      - generic [ref=e36]:
        - generic [ref=e37]:
          - button "Back" [ref=e38] [cursor=pointer]:
            - img [ref=e39]
            - text: Back
          - button "Swap start and destination" [ref=e41] [cursor=pointer]:
            - img [ref=e42]
        - heading "Directions" [level=2] [ref=e45]
        - paragraph [ref=e46]: From
        - generic [ref=e47]:
          - generic [ref=e48]:
            - img [ref=e49]
            - combobox "Route start" [active] [ref=e52]: 05-411 · Office
            - button "Clear route start" [ref=e53] [cursor=pointer]:
              - img [ref=e54]
          - generic [ref=e57]: Library · Floor 4
        - paragraph [ref=e58]: To
        - generic [ref=e59]:
          - generic [ref=e60]:
            - img [ref=e61]
            - combobox "Route destination" [ref=e64]: 05-341 · Seminar
            - button "Clear route destination" [ref=e65] [cursor=pointer]:
              - img [ref=e66]
          - generic [ref=e69]: Library · Floor 3
        - paragraph [ref=e70]: Select From or To to change a location.
        - generic [ref=e71]:
          - generic [ref=e72]: Route profile
          - button "Route profile" [ref=e73] [cursor=pointer]:
            - img [ref=e74]
            - generic [ref=e77]: Walking
            - img [ref=e78]
        - generic [ref=e80]:
          - generic [ref=e81]: Route endpoints
          - button "Route endpoints" [ref=e82] [cursor=pointer]:
            - img [ref=e83]
            - generic [ref=e86]: Hallway outside door
            - img [ref=e87]
        - generic "Average straight hallway sections. Hallway directions start and end at the center near each selected door." [ref=e89]:
          - checkbox "Use hallway centerlines" [checked] [ref=e90]
          - text: Use hallway centerlines
        - group [ref=e91]:
          - generic "Excluded stairs · 0" [ref=e92]
        - generic [ref=e93]:
          - strong [ref=e94]: 119.7 m · 3 min
          - paragraph [ref=e95]: 1 floor change · 12 turns
          - paragraph [ref=e96]: Public access is unknown for 39 areas.
          - paragraph [ref=e97]: Step-free access is unconfirmed for 28 connections.
          - paragraph [ref=e98]: This route passes through 05-423 · Archives open area, 05-430 · Archives Collections Storage, 05-425 · Office. Check that these rooms permit passage.
          - button "Preview directions" [ref=e99] [cursor=pointer]
      - button "Fit route" [ref=e100] [cursor=pointer]
      - generic [ref=e101]:
        - generic [ref=e102]:
          - button "Zoom in" [ref=e103] [cursor=pointer]:
            - img [ref=e104]
          - button "Zoom out" [ref=e105] [cursor=pointer]:
            - img [ref=e106]
        - generic [ref=e107]:
          - button "Reset north" [ref=e108] [cursor=pointer]:
            - img [ref=e109]
          - button "Reset pitch" [ref=e112] [cursor=pointer]:
            - img [ref=e113]
          - button "Toggle fullscreen" [ref=e116] [cursor=pointer]:
            - img [ref=e117]
```

# Test source

```ts
  113 |             } catch {
  114 |               return [];
  115 |             }
  116 |           });
  117 |         const candidates = rows
  118 |           .filter(
  119 |             (r) =>
  120 |               r.available &&
  121 |               r.mode === "public" &&
  122 |               r.tags.some((t: string) => t.startsWith("every-floor")) &&
  123 |               r.transitions.length === 0 &&
  124 |               [r.start, r.end].every((k) => {
  125 |                 const place = records.get(k);
  126 |                 return (
  127 |                   place &&
  128 |                   place.levelId === 402_367 &&
  129 |                   place.number &&
  130 |                   !place.stair &&
  131 |                   !isVisitorHallway(place) &&
  132 |                   !isPassThroughPlace(place)
  133 |                 );
  134 |               }),
  135 |           )
  136 |           .sort((a, b) => b.distanceMetres - a.distanceMetres);
  137 |         same = candidates[0];
  138 |         return !!same;
  139 |       },
  140 |       { timeout: 600_000, intervals: [2000] },
  141 |     )
  142 |     .toBe(true);
  143 |   const from = records.get(same!.start)!,
  144 |     to = records.get(same!.end)!;
  145 |   await page.getByLabel("Search indoor map", { exact: true }).fill(to.number);
  146 |   await page
  147 |     .getByRole("button", { name: new RegExp(`^${escape(to.number)} ·`) })
  148 |     .click();
  149 |   await page.getByRole("button", { name: "Directions", exact: true }).click();
  150 |   const select = async (label: string, place: IndoorRecord) => {
  151 |     await page.getByLabel(label, { exact: true }).fill(place.number);
  152 |     await page
  153 |       .getByRole("option", { name: new RegExp(`^${escape(place.number)} ·`) })
  154 |       .click();
  155 |   };
  156 |   const waitRoute = async (start: string, end: string) => {
  157 |     await expect
  158 |       .poll(
  159 |         async () =>
  160 |           (await replies(page)).some((r) => r.start === start && r.end === end),
  161 |         { timeout: 900_000, intervals: [1000] },
  162 |       )
  163 |       .toBe(true);
  164 |     const reply = (await replies(page)).findLast(
  165 |       (r) => r.start === start && r.end === end,
  166 |     )!;
  167 |     expect(reply.route, reply.diagnostic?.message).not.toBeNull();
  168 |     await expect(page.getByTestId("project-route-result")).toBeVisible();
  169 |     await expect(page.getByTestId("project-route-result")).toContainText(
  170 |       `${reply.route!.distanceMetres.toFixed(1)} m`,
  171 |     );
  172 |     return reply;
  173 |   };
  174 |   const readyFloor = async () => {
  175 |     await expect(
  176 |       page.getByRole("progressbar", { name: /^Preparing / }),
  177 |     ).toBeHidden({ timeout: 900_000 });
  178 |   };
  179 |   await select("Route start", from);
  180 |   const floorReply = await waitRoute(from.key, to.key);
  181 |   expect(floorReply.route!.edges.map((e) => e.id)).toEqual(same!.sourceEdgeIds);
  182 |   expect(
  183 |     floorReply.route!.paths.every((p) =>
  184 |       p.levelIds.every((id) => id === 402_367),
  185 |     ),
  186 |   ).toBe(true);
  187 |   await readyFloor();
  188 |   await page.getByRole("button", { name: "Fit route", exact: true }).click();
  189 |   await page.waitForTimeout(800);
  190 |   await page.screenshot({
  191 |     path: path.join(output!, "desktop-full-floor-route.png"),
  192 |   });
  193 |   await page
  194 |     .getByRole("button", { name: "Preview directions", exact: true })
  195 |     .click();
  196 |   await page.setViewportSize({ width: 390, height: 844 });
  197 |   await expect(page.getByTestId("mobile-current-instruction")).toBeVisible();
  198 |   await page.getByRole("button", { name: "Fit route", exact: true }).click();
  199 |   await page.waitForTimeout(800);
  200 |   await page.screenshot({
  201 |     path: path.join(output!, "mobile-full-floor-route.png"),
  202 |   });
  203 |   await page
  204 |     .getByRole("button", { name: "Close", exact: true })
  205 |     .filter({ visible: true })
  206 |     .click();
  207 |   await page.setViewportSize({ width: 1440, height: 1000 });
  208 |   const upper = [...records.values()].find((r) => r.number === "05-411")!,
  209 |     lower = [...records.values()].find((r) => r.number === "05-341")!;
  210 |   await select("Route destination", lower);
  211 |   await select("Route start", upper);
  212 |   const multi = await waitRoute(upper.key, lower.key);
> 213 |   expect(multi.worker).toBe(floorReply.worker);
      |                        ^ Error: expect(received).toBe(expected) // Object.is equality
  214 |   const lift = multi.route!.edges.find((e) => e.kind === "elevator");
  215 |   expect(lift).toBeDefined();
  216 |   expect(multi.route!.paths.some((p) => p.levelIds.includes(402_367))).toBe(
  217 |     true,
  218 |   );
  219 |   expect(multi.route!.paths.some((p) => p.levelIds.includes(400_176))).toBe(
  220 |     true,
  221 |   );
  222 |   expect(multi.route!.edges.some((e) => e.kind === "stairs")).toBe(false);
  223 |   await page
  224 |     .getByRole("button", { name: "Preview directions", exact: true })
  225 |     .click();
  226 |   await readyFloor();
  227 |   await page.waitForTimeout(800);
  228 |   await page.getByRole("button", { name: "Fit route", exact: true }).click();
  229 |   await page.waitForTimeout(800);
  230 |   await page.screenshot({
  231 |     path: path.join(output!, "desktop-multifloor-upper.png"),
  232 |   });
  233 |   const transition = page
  234 |     .getByTestId("hospital-step-list")
  235 |     .getByRole("button", { name: /Take the elevator down/ });
  236 |   await transition.click();
  237 |   await page.waitForTimeout(800);
  238 |   await readyFloor();
  239 |   await expect(transition).toHaveAttribute("aria-current", "step");
  240 |   await page.waitForTimeout(800);
  241 |   await page.screenshot({
  242 |     path: path.join(output!, "desktop-lift-transition.png"),
  243 |   });
  244 |   await page
  245 |     .getByRole("button", { name: "Next step", exact: true })
  246 |     .filter({ visible: true })
  247 |     .click();
  248 |   await page.waitForTimeout(800);
  249 |   await readyFloor();
  250 |   await page.waitForTimeout(800);
  251 |   await page.screenshot({
  252 |     path: path.join(output!, "desktop-multifloor-lower.png"),
  253 |   });
  254 |   await page.setViewportSize({ width: 390, height: 844 });
  255 |   await expect(page.getByTestId("mobile-route-floor")).toContainText("Floor 3");
  256 |   await page
  257 |     .getByRole("button", { name: "Previous step", exact: true })
  258 |     .filter({ visible: true })
  259 |     .click();
  260 |   await expect(page.getByTestId("mobile-current-instruction")).toContainText(
  261 |     "elevator down",
  262 |   );
  263 |   await page.waitForTimeout(700);
  264 |   await page.screenshot({
  265 |     path: path.join(output!, "mobile-lift-transition.png"),
  266 |   });
  267 |   await page
  268 |     .getByRole("button", { name: "Next step", exact: true })
  269 |     .filter({ visible: true })
  270 |     .click();
  271 |   await expect(page.getByTestId("mobile-route-floor")).toContainText("Floor 3");
  272 |   await page.waitForTimeout(700);
  273 |   await page.screenshot({
  274 |     path: path.join(output!, "mobile-multifloor-lower.png"),
  275 |   });
  276 |   expect(errors).toEqual([]);
  277 |   await writeFile(
  278 |     path.join(output!, "browser-proof.json"),
  279 |     JSON.stringify(
  280 |       {
  281 |         status: "passed",
  282 |         errors,
  283 |         sameFloorCase: {
  284 |           start: from.key,
  285 |           end: to.key,
  286 |           from: from.number,
  287 |           to: to.number,
  288 |         },
  289 |         multifloorCase: {
  290 |           start: upper.key,
  291 |           end: lower.key,
  292 |           from: upper.number,
  293 |           to: lower.number,
  294 |         },
  295 |         sameWorker: true,
  296 |         replies: await replies(page),
  297 |       },
  298 |       null,
  299 |       2,
  300 |     ),
  301 |   );
  302 | });
  303 | 
```