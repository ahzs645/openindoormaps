// Diagnostic only: preserve the native digest and every byte/check, but allow
// the completed native job to release its input snapshot before the next large
// synchronous allocation. This file is not an application/runtime patch.
import { setImmediate } from "node:timers/promises";
if (typeof globalThis.gc !== "function")
  throw new Error("The digest memory diagnostic requires --expose-gc.");
const subtle = globalThis.crypto.subtle;
const nativeDigest = subtle.digest;
let calls = 0;
Object.defineProperty(subtle, "digest", {
  configurable: true,
  writable: true,
  value: async function (algorithm, data) {
    const bytes = data.byteLength;
    const result = await Reflect.apply(nativeDigest, this, [algorithm, data]);
    calls++;
    if (bytes >= 1024 * 1024 || calls % 32 === 0) {
      const before = process.memoryUsage();
      await setImmediate();
      globalThis.gc();
      process.stderr.write(JSON.stringify({
        diagnostic: "native-digest-turn-and-gc",
        call: calls,
        bytes,
        before,
        after: process.memoryUsage(),
        maxRSSKiB: process.resourceUsage().maxRSS,
      }) + "\n");
    }
    return result;
  },
});
