// Targeted effect-lifecycle reproduction; does not claim browser or React integration coverage.
import assert from "node:assert/strict";
import fs from "node:fs";
import { stripTypeScriptTypes } from "node:module";
import vm from "node:vm";
import test from "node:test";

const root = new URL("./", import.meta.url);
const layerPath = "app/components/map/basemap-3d-buildings-layer.tsx";
const helper = fs.readFileSync(new URL("app/components/map/map-ready.ts", root), "utf8");
const eraseTypesAndImports = (source) =>
  stripTypeScriptTypes(source)
    .replace(/^import .*;\n/gm, "")
    .replace(/export function /g, "function ");

function effect(map, { original = false, enabled = true, isLoaded = true } = {}) {
  const source = fs.readFileSync(new URL((original ? "base/" : "") + layerPath, root), "utf8");
  let cleanup;
  const context = vm.createContext({
    useMap: () => ({ map, isLoaded }),
    useEffect: (run) => { cleanup = run(); },
    options: { enabled },
  });
  vm.runInContext(
    eraseTypesAndImports(helper) + "\n" + eraseTypesAndImports(source) +
      "\nBasemap3dBuildingsLayer(options);",
    context,
  );
  return cleanup;
}

function fakeMap({ existing = false, source = true } = {}) {
  const calls = [];
  const layers = new Map(existing ? [["basemap-3d-buildings", { id: "basemap-3d-buildings" }]] : []);
  const map = {
    style: { layers: [{ id: "labels", type: "symbol" }] },
    getLayer(id) {
      calls.push(["getLayer", id]);
      if (map.style === undefined) throw new TypeError("Cannot read properties of undefined (reading 'getLayer')");
      return layers.get(id);
    },
    getSource(id) {
      calls.push(["getSource", id]);
      if (map.style === undefined) throw new TypeError("Cannot read properties of undefined (reading 'getSource')");
      return source ? {} : undefined;
    },
    getStyle() { return map.style; },
    addLayer(layer, before) {
      calls.push(["addLayer", layer.id, before]);
      layers.set(layer.id, layer);
    },
    removeLayer(id) {
      calls.push(["removeLayer", id]);
      layers.delete(id);
    },
  };
  return { map, calls, layers };
}

test("the exact PR-head effect reproduces the reported cleanup crash after map.remove", () => {
  const { map } = fakeMap();
  const cleanup = effect(map, { original: true });
  map.style = undefined;
  assert.throws(cleanup, /Cannot read properties of undefined.*getLayer/);
});

test("the guarded effect never queries or removes a destroyed map during cleanup", () => {
  const { map, calls } = fakeMap();
  const cleanup = effect(map);
  map.style = undefined;
  calls.length = 0;
  assert.doesNotThrow(cleanup);
  assert.deepEqual(calls, []);
});

test("a stale loaded flag cannot add a layer to a destroyed map", () => {
  const { map, calls } = fakeMap();
  map.style = undefined;
  assert.equal(effect(map), undefined);
  assert.deepEqual(calls, []);
});

test("ordinary mounting preserves the exact layer specification, position and cleanup", () => {
  const before = fakeMap(), after = fakeMap();
  const previousCleanup = effect(before.map, { original: true });
  const nextCleanup = effect(after.map);
  assert.equal(JSON.stringify([...after.layers]), JSON.stringify([...before.layers]));
  assert.deepEqual(after.calls, before.calls);
  previousCleanup();
  nextCleanup();
  assert.deepEqual(after.calls, before.calls);
  assert.equal(after.layers.size, 0);
});

test("disabled, unloaded and absent maps remain inactive", () => {
  for (const options of [{ enabled: false }, { isLoaded: false }]) {
    const { map, calls } = fakeMap();
    assert.equal(effect(map, options), undefined);
    assert.deepEqual(calls, []);
  }
  assert.equal(effect(null), undefined);
});

test("an existing layer is neither replaced nor owned by this effect", () => {
  const { map, calls, layers } = fakeMap({ existing: true });
  assert.equal(effect(map), undefined);
  assert.deepEqual(calls, [["getLayer", "basemap-3d-buildings"]]);
  assert.equal(layers.size, 1);
});

test("a missing basemap source still prevents adding the buildings layer", () => {
  const { map, calls } = fakeMap({ source: false });
  assert.equal(effect(map), undefined);
  assert.ok(!calls.some(([name]) => name === "addLayer"));
});

test("cleanup tolerates a replaced style that already discarded the buildings layer", () => {
  const { map, calls, layers } = fakeMap();
  const cleanup = effect(map);
  layers.clear();
  calls.length = 0;
  assert.doesNotThrow(cleanup);
  assert.deepEqual(calls, [["getLayer", "basemap-3d-buildings"]]);
});
